# import pytest 

import os
import pytest
from svinsight import SVInsight