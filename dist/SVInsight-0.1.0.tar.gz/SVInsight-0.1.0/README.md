SVInisight: A python package for calculating an exploratory social vulnerability index (SVI)
